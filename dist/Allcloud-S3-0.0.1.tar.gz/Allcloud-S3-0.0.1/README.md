# Allcloud-S3
A package to wrap S3 Functionallity. Build for my team @Allcloud.

## Usage:
from S3Operations import S3Operations

s3_ops = S3Operations()
s3_ops.<function>